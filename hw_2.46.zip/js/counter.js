'use strict';
const btnStart = document.querySelector('#counter');
'use strict';
const btnStart = document.querySelector('#counter');